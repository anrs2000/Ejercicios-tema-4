public class Main {
    public static void main(String[] args) {
        int Numeroif = -3;
                if (Numeroif > 0) {
                    System.out.println("es positivo");
                } else if (Numeroif < 0){
                    System.out.println("es negativo");
                } else {
                    System.out.println("es cero");
        }
        {
        int NumeroWhile = 0;
        while (NumeroWhile < 3) {
            System.out.println(NumeroWhile);
            NumeroWhile = NumeroWhile + 1;
        }
        }

        {
        int NumeroWhile = 3;
        do {
            System.out.println(NumeroWhile);
            NumeroWhile = NumeroWhile +1;
        } while (NumeroWhile < 3);
        }

        {for (int numeroFor = 0; numeroFor <= 3; numeroFor = numeroFor + 1) {
            System.out.println(numeroFor);
        }
        }

        {
        var estacion = "INVIERNO";
        switch(estacion) {
            case "VERANO":
                System.out.println("es verano");
                break;
            case "INVIERNO":
                System.out.println("es invierno");
                break;
            case "PRIMAVERA":
                System.out.println("es primavera");
                break;
            case "OTOÑO":
                System.out.println("es otoño");
                break;
            default:
                System.out.println("no es ninguna estación");

        }
        }
    }
}